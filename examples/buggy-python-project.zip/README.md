# Example: Buggy Python Project

Use this small project to demo CodePilot AI. It intentionally contains a few simple bugs for a reviewer to find. This is demo data, not production code.
